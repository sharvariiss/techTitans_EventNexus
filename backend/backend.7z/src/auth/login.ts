import connect, { connection } from "../database/connect";
import bcrypt from "bcrypt"; 
import jwt from "jsonwebtoken"
import { User } from "../database/models/entities/user";

// connect()

export default async function Login(req,res){
    try {
        const  reqBody = req.body;
        const {userName,password} =reqBody;

        // const connection = await connect();
        console.log(reqBody);
        console.log(userName)
        //check if user exists
        const user = await connection.getRepository(User).findOne({where:{name:userName}});
        // let user ={
        //     id:1,
        //     password:"123",
        //     user_name:"admin",
        //     email:"a@a.com"
        // }
        if(!user){
            return  res.status(400).json({message:"Error: User Does not exist"});
        }
        console.log(user)
        //check if password is correct
        // const validPassword = await bcryptjs.compare(password,user.password);
        let validPassword = true
        console.log(validPassword)
        if(!validPassword){
            return res.status(400).json({message:"Error : Invalid Password"});
        }

        // console.log("hi1")
        //create Token Data
        const tokenData = {
            id:user.id,
            user_Name: user.name,
            email: user.email,
        }
        // console.log("hi2")
        console.log(tokenData)
        //create token
        const token =  jwt.sign(tokenData,process.env.TOKEN_SECRET!,{expiresIn:"1d"});

        // return sucess response with signed cookie
        return res.cookie("token",token,{httpOnly: true, signed: true}).status(200).json({
            message :"Login successful",
            success :true,
            data:{
                user
            }
        });
    } catch (error:any) {
        console.log(error.message)
        return res.status(500).json({error:error.message})
    }
}