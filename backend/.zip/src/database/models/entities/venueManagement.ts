import { BaseEntity, Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Committees } from "./committees";
import { Departments } from "./departments";
import { Event_Category } from "./event_category";

@Entity(`${process.env.VENUEMANAGEMENT_TABLE}`)
export class VenueManagement extends BaseEntity {
    @PrimaryGeneratedColumn()
    id:number;

    // Define a one-to-many relationship with the Committees entity for multiple venues
    @OneToMany(
        () => Committees,
        Committees => Committees.venue
    )
    committees: Committees[];

    // Define a one-to-many relationship with the Event entity for multiple venues
    @OneToMany(
        () => Event_Category,
        Event_Category => Event_Category.venue
    )
    event: Event_Category[];

    // Define a one-to-many relationship with the Departments entity for multiple venues
    @OneToMany(
        () => Departments,
        Departments => Departments.venue
    )
    department: Departments[];

    // Define a column for storing the date when the event has started
    @Column('date')
    start_date: Date;

    // Define a column for storing the date when the event has ended 
    @Column('date')
    end_date: Date;

    // Define columns for start_time and end_time of an event
    @Column('date')
    start_time: Date;

    @Column('date')
    end_time: Date;
    
}