import { BaseEntity, Column, Entity, PrimaryGeneratedColumn, OneToMany, ManyToOne, JoinColumn } from "typeorm";
import { Committee } from "./editCommittee";
import { VenueManagement } from "./venueManagement";

@Entity(`${process.env.DEPARTMENT_TABLE}`)
export class Departments extends BaseEntity {
    @PrimaryGeneratedColumn()
    id:number;

    @Column('varchar')
    name: string;

    // Define a one-to-many relationship with the Committee entity for multiple departments
    @OneToMany(
        () => Committee,
        Committee => Committee.department
    )
    committee: Committee[];

    // Define a many-to-one relationship with the VenueManagement entity
  @ManyToOne(
    () => VenueManagement,
    venue => venue.department,
    {
        onDelete: "CASCADE"
    }
  )
  @JoinColumn(
    {
        name: 'venue_management_id',
    }
  )
  // Create a property to access the associated VenueManagement entity
  venue: VenueManagement;
}