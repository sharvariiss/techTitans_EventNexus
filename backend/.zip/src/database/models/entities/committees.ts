import { BaseEntity, Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { VenueManagement } from "./venueManagement";

@Entity(`${process.env.COMMITTEES_TABLE}`)
export class Committees extends BaseEntity {
    @PrimaryGeneratedColumn()
    id:number;

    @Column('varchar')
    name: string;

    // Define a many-to-one relationship with the VenueManagement entity
  @ManyToOne(
    () => VenueManagement,
    venue => venue.committees,
    {
        onDelete: "CASCADE"
    }
  )
  @JoinColumn(
    {
        name: 'venue_management_id',
    }
  )
  // Create a property to access the associated VenueManagement entity
  venue: VenueManagement;

}