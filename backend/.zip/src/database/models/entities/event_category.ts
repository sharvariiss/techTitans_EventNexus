import { BaseEntity, Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { VenueManagement } from "./venueManagement";

@Entity(`${process.env.EVENT_CATEGORY_TABLE}`)
export class Event_Category extends BaseEntity {
    @PrimaryGeneratedColumn()
    id:number;

    @Column('varchar')
    name: string;

    // Define a many-to-one relationship with the VenueManagement entity
  @ManyToOne(
    () => VenueManagement,
    venue => venue.event,
    {
        onDelete: "CASCADE"
    }
  )
  @JoinColumn(
    {
        name: 'venue_management_id',
    }
  )
  // Create a property to access the associated VenueManagement entity
  venue: VenueManagement;
}