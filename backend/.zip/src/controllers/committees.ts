import { Response, Request } from "express";
import { connection } from "../database/connect";
import { Committees } from "../database/models/entities/committees";


export async function CreateCommittees(req: Request, res: Response) {
    const { name } = req.body;

    if (!name) return res.status(400).json({ message: "Please provide with a name for the Committee you are Trying to Create" })

    if (await connection.getRepository(Committees).createQueryBuilder(process.env.COMMITEES_TABLE).where({ name }).getOne())
        return res.status(400).json({ message: "Committee Already Exists" })

    await Committees.create({
        name
    }).save()

    return res.status(200).json({ message: "Committee created" })
}

export async function GetCommittees(req: Request, res: Response) {
    const { id } = req.query;

    let committees: Committees | Committees[];

    if (id)
    committees = await connection.getRepository(Committees).createQueryBuilder(process.env.COMMITEES_TABLE).where({ id }).getOne()
    else
    committees = await connection.getRepository(Committees).createQueryBuilder(process.env.COMMITEES_TABLE).getMany()

    if (!committees) return res.status(404).json({ message: "No Committees Found" })

    return res.status(200).json({ message: "Committees Fetched", committees })
}

export async function DeleteCommittees(req: Request, res: Response) {
    const { id } = req.query;

    const committees = await connection.getRepository(Committees).createQueryBuilder(process.env.COMMITEES_TABLE).where({ id }).getOne();

    if (!committees) return res.status(404).json({ message: "No Committees Found" })

    await connection.getRepository(Committees).createQueryBuilder(process.env.COMMITEES_TABLE).delete().where({ id }).execute();

    return res.status(200).json({ message: "Committees Deleted" })
}