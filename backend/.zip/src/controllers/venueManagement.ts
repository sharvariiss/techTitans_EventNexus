import { VenueManagement } from "src/database/models/entities/venueManagement";
import { connection } from "../database/connect";
import { Venue } from "src/database/models/entities/venue";
import { Committees } from "src/database/models/entities/committees";
import { Departments } from "src/database/models/entities/departments";


export async function CreateVenueManagement(req, res) {
    try {
        // Get required data from request
        const reqBody = req.body;
        const {

            start_date,
            end_date,
            start_time,
            end_time,
            venue_id,
            committees_id,
            dept_id,
            event_id } = reqBody;

        // Check if Venue Management already exists

        const venue_Management = await connection.getRepository(VenueManagement)
            .createQueryBuilder(process.env.VENUEMANAGEMENT_TABLE)
            .leftJoinAndSelect(process.env.VENUEMANAGEMENT_TABLE + '.venue', "venue")
            .leftJoinAndSelect(process.env.VENUEMANAGEMENT_TABLE + '.event', "event")
            .leftJoinAndSelect(process.env.VENUEMANAGEMENT_TABLE + '.committees', "committees")
            .leftJoinAndSelect(process.env.VENUEMANAGEMENT_TABLE + '.department', "department")
            .where("venue_management.id= :id", { id: venue_management_id })
            .andWhere("start_date= :start_date", { start_date: start_date })
            .getOne();
        // check wether Venue Management already exists
        if (venue_Management) {
            return res.status(400).json({ message: "Venue Management Already Exists" });
        }
        // Query the venue
        const venue = await connection
            .getRepository(Venue)
            .createQueryBuilder(process.env.VENUE_TABLE)
            .where({ id: venue_id })
            .getOne()
        
        if (!venue) {
            return res.status(400).json({ message: "Venue does not Exists" });
        }
        //Query the Event
        const event_category = await connection
            .getRepository(Event)
            .createQueryBuilder(process.env.EVENT_TABLE)
            .where({ id: event_id })
            .getOne()
        if (!event_category) {
            return res.status(400).json({ message: "Event does not Exists" });
        }
        
        //Query the Committees
        const committees = await connection
            .getRepository(Committees)
            .createQueryBuilder(process.env.COMMITTEES_TABLE)
            .where({ id: committees_id })
            .getOne()
        if (!committees) {
            return res.status(400).json({ message: "Committees does not Exists" });
        }

        //Query the Department
        const departments = await connection
            .getRepository(Departments)
            .createQueryBuilder(process.env.DEPARTMENT_TABLE)
            .where({ id: dept_id })
            .getOne()
        if (!departments) {
            return res.status(400).json({ message: "Department does not Exists" });
        }
        

        // Create a new VenueManagement
        const venueManagement = VenueManagement.create({
            start_date: start_date,
            end_date: end_date,
            start_time: start_time,
            end_time: end_time
        })
        // Save the Venue in the database
        const savedVenueManagement = await venueManagement.save();

        return res.status(200).json({ message: "Venue Management Created", VenueManagement: savedVenueManagement });
    } catch (error) {
        console.error(error.message);
        return res.status(500).json({ message: "Internal Server Error" });
    }
}


export async function GetVenueManagement(req: Request, res: Response) {
    try {
        // Get required data from the request body
        const reqBody = req.query;
        const { venue_management_id } = reqBody;

        let venueManagement;

        // Get the VenueManagement by ID
        if (venue_management_id)
            venueManagement = await connection.getRepository(VenueManagement)
                .createQueryBuilder(process.env.VENUEMANAGEMENT_TABLE)
                .where({ id: venue_management_id }).getOne();
        // // Get the VenueManagement by name
        // else if (college_name)
        //     venueManagement = await connection.getRepository(Institute)
        //         .createQueryBuilder(process.env.INSTITUTE_TABLE)
        //         .where({ college_name: college_name })
        //         .getOne();

        // Handle the case where the VenueManagement is not found
        if (!venueManagement) {
            return res.status(404).json({ message: "Venue Management not found" });
        }

        // Return a success response with the found VenueManagement
        return res.status(200).json({ message: "Venue Management found", venueManagement: venueManagement });
    } catch (error) {
        // Log and return an error response for any unexpected errors
        console.log(error.message);
        return res.status(500).json({ message: error.message });
    }
}

// Define the function to handle the deletion of a VenueManagement
export async function DeleteVenueManagement(req: Request, res: Response) {
    try {
        // Get required data from the request body
        const reqBody = req.body;
        const { venue_management_id } = reqBody;

        let venueManagement;

        // Check if venueManagementId is provided for deletion by ID
        if (venue_management_id)
            venueManagement = await connection.getRepository(VenueManagement)
                .createQueryBuilder(process.env.INSTITUTE_TABLE)
                .delete()
                .where({ id: venue_management_id })
                .execute();
        // // Delete the institute by name
        // else if (college_name)
        //     venueManagement = await connection.getRepository(Institute)
        //         .createQueryBuilder(process.env.INSTITUTE_TABLE)
        //         .delete()
        //         .where({ college_name: college_name })
        //         .execute();

        // Check if the VenueManagement was not found for deletion
        if (venueManagement.affected === 0)
            return res.status(404).json({ message: "Venue Management not found" });

        // Return a success response after successful deletion
        return res.status(200).json({ message: "Venue Management Deleted" });
    } catch (error) {
        // Log and return an error response for any unexpected errors
        console.log(error.message);
        return res.status(500).json({ error: error.message });
    }
}


// Define the function to handle the update of a institute
export async function UpdateInstitute(req: Request, res: Response) {
    try {
        // Get required data from the request body
        const reqBody = req.body;
        const { venue_management_id, college_name, college_code, address, email, password, verify_at } = reqBody;

        // Connect to the institute repository in the database
        const instituteRepository = await connection.getRepository(Institute);

        // Prepare an object with non-undefined fields from the request body for updating the institute
        const updateObject: Partial<Institute> = {};
        if (college_name !== undefined) updateObject.college_name = college_name;
        if (college_code !== undefined) updateObject.college_code = college_code;
        if (email !== undefined) updateObject.email = email;
        if (password !== undefined) updateObject.password = password;
        if (verify_at !== undefined) updateObject.verify_at = verify_at;
        if (address !== undefined) updateObject.address = address;

        // Declare a variable to store the result of the update operation
        let savedInstitute;

        // Check if there are fields to update in the institute
        if (Object.keys(updateObject).length > 0) {
            // Perform the update operation in the database
            savedInstitute = await instituteRepository.update(
                { id: venue_management_id },
                updateObject
            );
        } else {
            // If no fields to update, return a 400 response with an appropriate message
            return res.status(400).json({ message: "Institute doesn't exist" });
        }

        // Check if the institute exists based on the update operation result
        if (savedInstitute !== undefined && savedInstitute.affected === 0) {
            // If no institute was updated, return a 400 response with an appropriate message
            return res.status(400).json({ message: "Institute doesn't exist" });
        }

        // Return a successful response if the institute was successfully updated
        return res.status(200).json({ message: "Institute updated" });
    } catch (error) {
        // Handle any errors that occur during the update process and return a 500 response with an error message
        console.log(error.message);
        return res.status(500).json({ message: error.message });
    }
}


